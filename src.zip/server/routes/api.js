const express = require('express');
const router = express.Router();
const MongoClient = require('mongodb').MongoClient;
 var  ObjectID = require('mongodb').ObjectID;

const db = MongoClient.connect('mongodb://localhost:27017/john', function(err, db) {
  if (err) throw err;
  myUsers = db.collection('users');
  comDet = db.collection('companies');
  myPost = db.collection('myPost');

});

/* GET api listing. */
router.get('/', (req, res) => {
  res.send('api works');
});


// <!--Add Users-->
router.post('/register', (req, res) => {
  let name = req.body.name;
  let email = req.body.email;
  let phone = req.body.phone;
  let address = req.body.address;
  
myUsers.insertOne({ name: name, email: email, phone: phone, address: address }, function(err, res) {
    console.log('1document insterted')
    if (err) throw err;
  });

  return res.json({success: true})
});

// Get users
router.get('/allusers', (req, res) => {
  myUsers.find({}).toArray(function(err, result) {
    return res.json({success: true, data: result, message: 'Enjoy Your Token'});
  });  
});



// <!--Add Company-->
router.post('/company', (req, res) => {
  let name = req.body.name;
  let cemail = req.body.cemail;
  let phone = req.body.phone;
  let address = req.body.address;
  let city = req.body.city;
  
comDet.insertOne({ name: name, cemail: cemail, phone: phone, address: address, city: city }, function(err, res) {
    console.log('1document insterted')
    if (err) throw err;
  });

  return res.json({success: true, data: result})
});


// Get Company
router.get('/users', (req, res) => {
  comDet.find({}).toArray(function(err, result) {
    return res.json({success: true, data: result, message: 'Enjoy Your Token'});
  });  
});

// <!--Update Company-->
router.post('/upcompany',(req, res)=> {

   var obj_id = new ObjectID(req.body._id);
  comDet.updateOne({"_id": obj_id},{$set: req.body.data},function(err, res) {
    console.log('1document updated')
    if (err) throw err;
  });

  return res.json({success: true})
});



router.get('/deleteuser/:id',function(req, res) {
    
    var obj_id = new ObjectID(req.params.id);
    myUsers.deleteOne({"_id":obj_id}, function(err, result) {
      if(err) {
        return res.json({success: false, data: req.params.id, message: 'Enjoy Your Token'});
      }  else {
        return res.json({success: true, data: req.params.id, message: 'Enjoy Your Token'});
      }

    })
    
})

router.get('/deletereguser/:id',function(req, res) {
    
    var obj_id = new ObjectID(req.params.id);
    comDet.deleteOne({"_id":obj_id}, function(err, result) {
      if(err) {
        return res.json({success: false, data: req.params.id, message: 'Enjoy Your Token'});
      }  else {
        return res.json({success: true, data: req.params.id, message: 'Enjoy Your Token'});
      }

    })
    
})



router.get('/deleteposts/:id',function(req, res) {
    
    var obj_id = new ObjectID(req.params.id);
    myPost.deleteOne({"_id":obj_id}, function(err, result) {
      if(err) {
        return res.json({success: false, data: req.params.id, message: 'Enjoy Your Token'});
      }  else {
        return res.json({success: true, data: req.params.id, message: 'Enjoy Your Token'});
      }

    })
    
})




// <!--Add post-->
router.post('/post', (req, res) => {
  let title = req.body.title;
  
myPost.insertOne({ title: title}, function(err, res) {
    console.log('1document insterted')
    if (err) throw err;
  });

  return res.json({success: true})
});

// Get post
router.get('/posts', (req, res) => {
  myPost.find({}).toArray(function(err, result) {
    return res.json({success: true, data: result, message: 'Enjoy Your Token'});
  });  
});



module.exports = router;