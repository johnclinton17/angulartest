import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'], 
  moduleId: module.id
})
export class AppComponent {
  today: number = Date.now();
}
