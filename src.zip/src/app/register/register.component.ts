import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RegisterService } from '../register.service';
import { DataService } from '../data.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
 
private user: Array<any> = [];
private newAttribute: any = {};
public dummyvalue: any;


// Define a users property to hold our user data
 users: Array<any>;

  constructor(private registerService:RegisterService, private _dataService: DataService) {

    // Access the Data Service's getUsers() method we defined
    
        
  }
   
getUserlist() {
  this._dataService.getUsers()  
        .subscribe(res => this.users = res);
}

 registerval = {name:'', email:'',phone:'',address:''}

deleteFieldValue2(index) {

var r = confirm("Are you sure to delete");
if (r == true) {
   this._dataService.deleteRegusers(index)
      .subscribe(res => {
      if(res['success']) {
            this.getUserlist();
          }
          else {
            this.dummyvalue = " Cant able to Delete";
          }
      })
}
     
   }


onSubmit()
{ 

   this.registerService.regValue(this.registerval.name,this.registerval.email,this.registerval.phone,this.registerval.address)
 .subscribe()


}


  ngOnInit() {
  this.getUserlist();
  }


}
