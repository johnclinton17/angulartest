import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RegisterService } from '../../register.service';
import { DataService } from '../../data.service';

@Component({
  selector: 'app-viewpost',
  templateUrl: './viewpost.component.html',
  styleUrls: ['./viewpost.component.css']
})
export class ViewpostComponent implements OnInit {

  posts: Array<any>;

  constructor(private registerService:RegisterService, private _dataService: DataService) {

    // Access the Data Service's getUsers() method we defined
    
        
  }

  registerval = {title:''}

  onSubmit()
	{ 

	   this.registerService.postValue(this.registerval.title)
	 .subscribe();
   location.reload();


	}

  ngOnInit() {
  }

}
