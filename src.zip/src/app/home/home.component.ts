import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
moduleId: module.id, 	
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
	
	model: any = {};
    loading = false;
    returnUrl: string;

  constructor(
  		private route: ActivatedRoute,
        private router: Router,) { }

  ngOnInit() {
  }

}
